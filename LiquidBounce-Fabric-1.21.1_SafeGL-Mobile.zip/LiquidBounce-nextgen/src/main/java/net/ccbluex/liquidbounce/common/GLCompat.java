/*
 * SafeGL 3.0 compatibility helper for mobile GL4ES / Pojav / FCL
 */
package net.ccbluex.liquidbounce.common;

import net.ccbluex.liquidbounce.common.OutlineFlag;

import org.lwjgl.opengl.GL11;

public class GLCompat {

    public static boolean safeMode = false;
    public static String detectedVersion = "unknown";
    public static String detectedRenderer = "unknown";

    public static void checkGLVersion() {
        try {
            String ver = GL11.glGetString(GL11.GL_VERSION);
            String rend = GL11.glGetString(GL11.GL_RENDERER);
            detectedVersion = ver != null ? ver : "unknown";
            detectedRenderer = rend != null ? rend : "unknown";

            System.out.println("[SafeGL] Detected OpenGL version: " + detectedVersion);
            System.out.println("[SafeGL] Detected Renderer: " + detectedRenderer);

            // Enable safe mode if running on GL 3.0* or GL4ES/mobile renderers
            if (detectedVersion.startsWith("3.0")
                || detectedRenderer.toLowerCase().contains("gl4es")
                || detectedRenderer.toLowerCase().contains("mobile")
                || detectedRenderer.toLowerCase().contains("pojav")) {
                safeMode = true;
                System.out.println("[SafeGL] Enabling compatibility mode for GL 3.0 / Mobile");
                OutlineFlag.drawOutline = false; // disable fancy outline on mobile
            }
        } catch (Throwable t) {
            // If querying GL fails, stay conservative
            safeMode = true;
            System.out.println("[SafeGL] Failed to query GL version, enabling safe mode. " + t);
            OutlineFlag.drawOutline = false;
        }
    }
}
