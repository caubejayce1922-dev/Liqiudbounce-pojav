package net.ccbluex.liquidbounce.utils;

import org.lwjgl.opengl.GL11;

public class GLCompat {

    public static boolean safeMode = false;

    public static void checkGLVersion() {
        String glVersion = GL11.glGetString(GL11.GL_VERSION);
        String renderer = GL11.glGetString(GL11.GL_RENDERER);

        System.out.println("[SafeGL] Detected OpenGL version: " + glVersion);
        System.out.println("[SafeGL] Detected Renderer: " + renderer);

        if (glVersion != null && (
            glVersion.startsWith("3.0") ||
            (renderer != null && renderer.toLowerCase().contains("gl4es"))
        )) {
            safeMode = true;
            System.out.println("[SafeGL] Enabling compatibility mode for GL 3.0 / Mobile GL4ES");
        }
    }
}
