<div class="divider"></div>

<style lang="scss">
  @use "../../../../colors.scss" as *;

  .divider {
    height: 100%;
    width: 4px;
    background-color: rgba($menu-base-color, .36);
    border-radius: 5px;
  }
</style>