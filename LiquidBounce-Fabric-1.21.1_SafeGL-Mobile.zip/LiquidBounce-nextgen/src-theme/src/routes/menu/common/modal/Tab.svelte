<div class="tab">
    <slot/>
</div>

<style lang="scss">
  .tab {
    margin: 0 15px;
    display: flex;
    flex-direction: column;
    row-gap: 40px;
  }
</style>