<img class="watermark" src="img/lb-logo.svg" alt="watermark" />

<style lang="scss">
    .watermark {
        //position: fixed;
        //top: 15px;
        //left: 15px;
        width: 165px;
    }
</style>
